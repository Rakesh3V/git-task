🚀Sleek and Simple Jakarta EE Project Template
=====================

minimalistic maven pom.xml for Jakarta EE 10 Projects with Java 21
